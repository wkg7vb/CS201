#pragma once
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
using namespace std;

void Menu(bool & again);
void OutputD(char userDep);
void OutputF();