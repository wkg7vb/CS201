#pragma once
#include "Student.h"
#include <vector>
#include <algorithm>
using namespace std;

void mySort(vector<Student>& roster);
void swap(vector<Student>& roster, int index1, int index2);